void initPalArray (UCHAR *palArray, int pal_type);
void add_sparkles_to_palette (UCHAR *palArray, int sparkle_amount);
void init_rgbw_palArray (UCHAR *palArray);
void init_w_palArray (UCHAR *palArray);
void init_w_half_palArray (UCHAR *palArray);
void init_pastel_palArray (UCHAR *palArray);
