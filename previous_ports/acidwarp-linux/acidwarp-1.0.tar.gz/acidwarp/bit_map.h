#define X_TITLE		80
#define Y_TITLE		98

#define NOAHS_FACE	0

void bit_map_uncompress (UCHAR *buf_graf, UCHAR *bit_data, int x_map, int y_map, int xmax, int ymax);
void writeBitmapImageToArray(UCHAR *buf_graf, int image_number, int xmax, int ymax);

